package dijkstra.graph


data class Graph(val graph: List<Map<Int, Long>>)