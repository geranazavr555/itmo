package system

interface DataHolderEnvironment {
    val batchSize: Int
}