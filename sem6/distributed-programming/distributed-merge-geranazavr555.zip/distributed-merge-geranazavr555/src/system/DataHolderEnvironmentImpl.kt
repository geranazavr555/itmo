package system

data class DataHolderEnvironmentImpl(override val batchSize: Int) : DataHolderEnvironment