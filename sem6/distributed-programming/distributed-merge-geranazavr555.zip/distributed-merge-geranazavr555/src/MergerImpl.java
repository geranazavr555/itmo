import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import system.MergerEnvironment;

import java.util.*;

public class MergerImpl<T extends Comparable<T>> implements Merger<T> {
    private final MergerEnvironment<T> mergerEnvironment;
    private final Map<Integer, List<T>> stepBatches;
    private final Map<Integer, Integer> batchI;
    private final SortedSet<Pair<T, Integer>> heap;

    public MergerImpl(MergerEnvironment<T> mergerEnvironment, Map<Integer, List<T>> prevStepBatches) {
        this.mergerEnvironment = mergerEnvironment;
        if (prevStepBatches != null) {
            this.stepBatches = new HashMap<>(prevStepBatches);
        } else {
            this.stepBatches = new HashMap<>();
        }
        this.batchI = new HashMap<>();
        for (int i = 0; i < mergerEnvironment.getDataHoldersCount(); i++) {
            this.batchI.put(i, 0);
        }
        this.heap = new TreeSet<>();

        for (int i = 0; i < mergerEnvironment.getDataHoldersCount(); i++) {
            if (this.stepBatches.containsKey(i)) {
                List<T> batch = this.stepBatches.get(i);
                if (!batch.isEmpty()) {
                    heap.add(new Pair<>(batch.get(0), i));
                }
            }
        }
    }

    private void fill() {
        for (int i = 0; i < mergerEnvironment.getDataHoldersCount(); i++) {
            if (!stepBatches.containsKey(i) || stepBatches.get(i).isEmpty() || batchI.get(i) >= stepBatches.get(i).size()) {
                List<T> batch = mergerEnvironment.requestBatch(i);
                if (!batch.isEmpty()) {
                    stepBatches.put(i, batch);
                    batchI.put(i, 0);
                    heap.add(new Pair<>(batch.get(0), i));
                }
            }
        }
    }

    private void shrink() {
        for (int i = 0; i < mergerEnvironment.getDataHoldersCount(); i++) {
            if (stepBatches.containsKey(i) && (stepBatches.get(i).isEmpty() || batchI.get(i) >= stepBatches.get(i).size())) {
                stepBatches.remove(i);
            }
        }
    }

    @Nullable
    @Override
    public T mergeStep() {
        fill();
        if (heap.isEmpty())
            return null;
        Pair<T, Integer> v = heap.first();
        heap.remove(v);
        batchI.put(v.b, batchI.get(v.b) + 1);
        fill();

        if (stepBatches.containsKey(v.b) && batchI.get(v.b) < stepBatches.get(v.b).size()) {
            heap.add(new Pair<>(stepBatches.get(v.b).get(batchI.get(v.b)), v.b));
        }

        return v.a;
    }

    @NotNull
    @Override
    public Map<Integer, List<T>> getRemainingBatches() {
        shrink();
        Map<Integer, List<T>> result = new HashMap<>();
        for (Integer i : stepBatches.keySet()) {
            result.put(i, new ArrayList<>(stepBatches.get(i).subList(batchI.get(i), stepBatches.get(i).size())));
        }
        return result;
    }

    private static class Pair<A extends Comparable<A>, B extends Comparable<B>> implements Comparable<Pair<A, B>> {
        private final A a;
        private final B b;

        private Pair(A a, B b) {
            this.a = a;
            this.b = b;
        }

        public A getA() {
            return a;
        }

        public B getB() {
            return b;
        }

        @Override
        public int compareTo(@NotNull Pair<A, B> o) {
            int result = this.a.compareTo(o.getA());
            if (result != 0) return result;
            return this.b.compareTo(o.b);
        }
    }
}
