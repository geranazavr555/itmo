import org.jetbrains.annotations.NotNull;
import system.DataHolderEnvironment;

import java.util.ArrayList;
import java.util.List;

public class DataHolderImpl<T extends Comparable<T>> implements DataHolder<T> {
    private final List<T> keys;
    private final DataHolderEnvironment dataHolderEnvironment;

    private int i;
    private int checkpointI;

    public DataHolderImpl(DataHolderEnvironment dataHolderEnvironment, List<T> keys) {
        this.keys = keys;
        this.dataHolderEnvironment = dataHolderEnvironment;
        this.checkpointI = 0;
        this.i = 0;
    }

    @Override
    public void checkpoint() {
        this.checkpointI = i;
    }

    @Override
    public void rollBack() {
        this.i = this.checkpointI;
    }

    @NotNull
    @Override
    public List<T> getBatch() {
        int batchSize = dataHolderEnvironment.getBatchSize();
        if (i + batchSize > keys.size()) {
            List<T> result = new ArrayList<>(keys.subList(i, keys.size()));
            i = keys.size();
            return result;
        }

        List<T> result = new ArrayList<>(keys.subList(i, i + batchSize));
        i += batchSize;
        return result;
    }
}
